import os
import torch
import torch.nn as nn
import numpy as np
from utils.dataset import GraphDataset
from helper import Trainer, Evaluator, collate
from option import Options
from models.GraphTransformer import Classifier
from tqdm import tqdm
import wandb
import gc

args = Options().parse()
n_class = args.n_class
data_path = args.data_path
model_path = args.model_path
if not os.path.isdir(model_path): os.mkdir(model_path)
task_name = args.task_name

batch_size = args.batch_size
use_amp = True

args.lr = 1e-4
args.weight_decay = 1e-4

def get_dataset(ids_file):
    ids = open(ids_file).readlines()
    return GraphDataset(os.path.join(data_path, ""), ids, site=args.site)

def run_training():
    data_file = "/home/ucl/inma/lhenneau/Cytology-fine-tuning/graph_transformer/tmi2022-main/data_txt"
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    fold_indices = list(range(15))

    wandb.init(project="graph_transformer", name=task_name, config={
        "lr": args.lr,
        "weight_decay": args.weight_decay,
        "epochs": args.num_epochs,
        "batch_size": batch_size,
        "folds": 15
    })

    for epoch in range(args.num_epochs):
        mean_train_loss, mean_train_acc = 0.0, 0.0
        mean_val_acc = 0.0
        mean_test_acc = 0.0

        for i in fold_indices:
            # ===> Chargement dynamique des datasets et loaders
            train_file = f"{data_file}/train_{i}.txt"
            val_file = f"{data_file}/val_{i}.txt"
            test_file = f"{data_file}/test_{i}.txt"

            dataset_train = get_dataset(train_file)
            dataset_val = get_dataset(val_file)
            dataset_test = get_dataset(test_file)

            train_loader = torch.utils.data.DataLoader(dataset=dataset_train, batch_size=batch_size, num_workers=0, collate_fn=collate, shuffle=True)
            val_loader = torch.utils.data.DataLoader(dataset=dataset_val, batch_size=batch_size, num_workers=0, collate_fn=collate, shuffle=False)
            test_loader = torch.utils.data.DataLoader(dataset=dataset_test, batch_size=batch_size, num_workers=0, collate_fn=collate, shuffle=False)

            # ===> Chargement modèle
            model = Classifier(n_class, n_features=args.n_features)
            model = nn.DataParallel(model).to(device)

            model_ckpt_path = os.path.join(model_path, f"fold_{i}.pt")
            if epoch > 0 and os.path.exists(model_ckpt_path):
                model.load_state_dict(torch.load(model_ckpt_path))

            optimizer = torch.optim.AdamW(model.parameters(), lr=args.lr, weight_decay=args.weight_decay)
            scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=args.num_epochs, eta_min=1e-6)

            trainer = Trainer(n_class)
            trainer.reset_metrics()

            # ===> TRAIN
            model.train()
            train_loss, total = 0.0, 0

            for sample in train_loader:
                with torch.cuda.amp.autocast(enabled=use_amp):
                    preds, labels, loss = trainer.train(sample, model, n_features=args.n_features)
                    optimizer.zero_grad()
                    if loss.dim() != 0:
                        loss = loss.mean()
                    loss.backward()
                    optimizer.step()
                    scheduler.step()

                    train_loss += loss.item()
                    total += len(labels)
                    trainer.metrics.update(labels, preds)

            train_loss /= total
            train_acc = trainer.get_scores()

            print(f"[Fold {i}] 🏋️‍♂️ Train loss: {train_loss:.4f}; acc: {train_acc:.4f}")
            mean_train_loss += train_loss
            mean_train_acc += train_acc

            # ===> VALIDATION
            model.eval()
            evaluator = Evaluator(n_class)
            evaluator.reset_metrics()

            with torch.no_grad():
                for sample in val_loader:
                    preds, labels, _ = evaluator.eval_test(sample, model, args.graphcam, n_features=args.n_features)
                    evaluator.metrics.update(labels, preds)

            val_acc = evaluator.get_scores()
            print(f"[Fold {i}] 🧪 Val acc: {val_acc:.4f}")
            mean_val_acc += val_acc

            # ===> SAUVEGARDE du modèle
            torch.save(model.state_dict(), os.path.join(model_path, f"fold_{i}.pt"))

            # ===> TEST
            evaluator.reset_metrics()
            with torch.no_grad():
                for batch in test_loader:
                    preds, labels, _ = evaluator.eval_test(batch, model, args.graphcam, n_features=args.n_features)
                    evaluator.metrics.update(labels, preds)

            test_acc = evaluator.get_scores()
            print(f"[Fold {i}] 🧪 Test acc: {test_acc:.4f}")
            mean_test_acc += test_acc

            # Nettoyage mémoire
            model.to("cpu")
            del model
            torch.cuda.empty_cache()
            gc.collect()

        mean_train_loss /= 15
        mean_train_acc /= 15
        mean_val_acc /= 15
        mean_test_acc /= 15

        wandb.log({
            "epoch": epoch + 1,
            "train_loss": mean_train_loss,
            "train_acc": mean_train_acc,
            "val_acc": mean_val_acc,
            "test_acc": mean_test_acc
        })

        print(f"\n📊 Epoch {epoch + 1}: Train loss={mean_train_loss:.4f}, Train acc={mean_train_acc:.4f}, Val acc={mean_val_acc:.4f}, Test acc={mean_test_acc:.4f}\n")

    wandb.finish()

if __name__ == "__main__":
    run_training()
