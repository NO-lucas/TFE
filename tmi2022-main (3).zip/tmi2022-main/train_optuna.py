#!/usr/bin/env python
# coding: utf-8

import os
import torch
import torch.nn as nn
from torchvision import transforms
from utils.dataset import GraphDataset
from utils.lr_scheduler import LR_Scheduler
from tensorboardX import SummaryWriter
from helper import Trainer, Evaluator, collate
from option import Options
from tqdm import tqdm
import numpy as np
from models.GraphTransformer import Classifier
from models.weight_init import weight_init

import optuna
from optuna.pruners import HyperbandPruner
from optuna.samplers import TPESampler
import logging
import sys
import gc

args = Options().parse()

n_class = args.n_class

torch.cuda.synchronize()
torch.backends.cudnn.deterministic = True

data_path = args.data_path
model_path = args.model_path
if not os.path.isdir(model_path): os.mkdir(model_path)
log_path = args.log_path
if not os.path.isdir(log_path): os.mkdir(log_path)
task_name = args.task_name

print(task_name)
train = args.train
test = args.test
graphcam = args.graphcam
print("train:", train, "test:", test, "graphcam:", graphcam)

batch_size = args.batch_size
accum_steps = 2  # Gradient accumulation
use_amp = True  # Mixed precision training

def get_dataset(ids_file):
    ids = open(ids_file).readlines()
    return GraphDataset(os.path.join(data_path, ""), ids, site=args.site)

def run_test_for_all_models(folds, fold_indices):
    test_accuracies = []
    for i, fold in enumerate(folds):
        print(f"🧪 Test evaluation for fold {i}")
        model = fold['model'].to("cuda")
        model.eval()

        test_file = f"/home/ucl/inma/lhenneau/Cytology-fine-tuning/graph_transformer/tmi2022-main/data_txt/test_{fold_indices[i]}.txt"
        test_dataset = get_dataset(test_file)
        test_loader = torch.utils.data.DataLoader(test_dataset, batch_size=batch_size, collate_fn=collate, shuffle=False)

        evaluator = Evaluator(n_class)
        with torch.no_grad():
            for batch in test_loader:
                preds, labels, _ = evaluator.eval_test(batch, model, graphcam, n_features=args.n_features)
                evaluator.metrics.update(labels, preds)

        acc = evaluator.get_scores()
        test_accuracies.append(acc)
        print(f"✅ Fold {i} test acc = {acc:.4f}")
        model.to("cpu")

    mean_test_acc = np.mean(test_accuracies)
    print(f"\n🏁 Mean test accuracy over 15 folds: {mean_test_acc:.4f}")
    return mean_test_acc

def objective(trial):
    lr = trial.suggest_loguniform("lr", 1e-5, 1e-2)
    weight_decay = trial.suggest_loguniform("weight_decay", 1e-6, 1e-1)

    args.lr = lr
    args.weight_decay = weight_decay

    return run_optuna(args, trial)

def run_optuna(args, trial):
    data_file = "/home/ucl/inma/lhenneau/Cytology-fine-tuning/graph_transformer/tmi2022-main/data_txt"
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    best_val_acc = 0.0
    best_model_path = os.path.join(model_path, f"best_model_trial_{trial.number}.pth")

    folds = []
    fold_indices = list(range(15))
    for i in fold_indices:
        train_file = f"{data_file}/train_{i}.txt"
        val_file = f"{data_file}/val_{i}.txt"

        dataset_train = get_dataset(train_file)
        dataset_val = get_dataset(val_file)

        dataloader_train = torch.utils.data.DataLoader(dataset=dataset_train, batch_size=batch_size, num_workers=0, collate_fn=collate, shuffle=True)
        dataloader_val = torch.utils.data.DataLoader(dataset=dataset_val, batch_size=batch_size, num_workers=0, collate_fn=collate, shuffle=False)

        model = Classifier(n_class, n_features=args.n_features)
        model = nn.DataParallel(model).to(device)

        optimizer = torch.optim.AdamW(model.parameters(), lr=args.lr, weight_decay=args.weight_decay)
        scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=args.num_epochs, eta_min=1e-6)

        trainer = Trainer(n_class)
        evaluator = Evaluator(n_class)

        folds.append({
            'model': model,
            'optimizer': optimizer,
            'scheduler': scheduler,
            'trainer': trainer,
            'evaluator': evaluator,
            'train_loader': dataloader_train,
            'val_loader': dataloader_val,
        })

    scaler = torch.cuda.amp.GradScaler(enabled=use_amp)

    for epoch in range(args.num_epochs):
        print(f"\n🔁 Epoch {epoch+1}/{args.num_epochs}")
        val_accuracies = []

        for i, fold in enumerate(folds):
            print(f"📂 Fold {i}")

            
            model = fold['model'].to("cuda")
            model.train()
            trainer = fold['trainer']
            trainer.reset_metrics()

            optimizer = fold['optimizer']
            scheduler = fold['scheduler']
            train_loader = fold['train_loader']

            optimizer.zero_grad()
            for j, sample in enumerate(train_loader):
                with torch.cuda.amp.autocast(enabled=use_amp):
                    preds, labels, loss = trainer.train(sample, model, n_features=args.n_features)
                    loss = loss.mean() / accum_steps
                scaler.scale(loss).backward()

                if (j + 1) % accum_steps == 0 or (j + 1) == len(train_loader):
                    scaler.step(optimizer)
                    scaler.update()
                    optimizer.zero_grad()

            scheduler.step()

            # Validation
            model.eval()
            evaluator = fold['evaluator']
            evaluator.reset_metrics()

            with torch.no_grad():
                for sample in fold['val_loader']:
                    preds, labels, _ = evaluator.eval_test(sample, model, graphcam, n_features=args.n_features)
                    evaluator.metrics.update(labels, preds)

            val_acc = evaluator.get_scores()
            val_accuracies.append(val_acc)
            print(f"✅ Fold {i} val acc = {val_acc:.4f}")
            model.to("cpu")

            # Clean up memory
            torch.cuda.empty_cache()
            gc.collect()

        mean_val_acc = sum(val_accuracies) / len(val_accuracies)
        print(f"\n📊 Epoch {epoch+1} - Mean val acc over 15 folds: {mean_val_acc:.4f}")

        trial.report(mean_val_acc, step=epoch)
        if trial.should_prune():
            print("⛔️ Trial pruned by Optuna.")
            raise optuna.exceptions.TrialPruned()

        


        if mean_val_acc > best_val_acc:
            best_val_acc = mean_val_acc
        
        torch.save(folds[0]['model'].state_dict(), best_model_path)
        print("🔍 Nouvelle meilleure validation trouvée, évaluation test...")
        mean_test_acc = run_test_for_all_models(folds, fold_indices)
        print(f"==> 🧪 Mean test evaluation : {mean_test_acc}")
        trial.set_user_attr("kfold_mean_acc", mean_test_acc)
            

    return best_val_acc

if __name__ == "__main__":
    optuna.logging.get_logger("optuna").addHandler(logging.StreamHandler(sys.stdout))
    study_name = "graph_transformer3"
    storage_name = f"sqlite:///{study_name}.db"
    study = optuna.create_study(
        direction="maximize",
        sampler=TPESampler(n_startup_trials=10),
        pruner=HyperbandPruner(min_resource=10, max_resource=80, reduction_factor=3),
        storage=storage_name,
        study_name=study_name,
        load_if_exists=True
    )

    study.optimize(objective, n_trials=50)

    print("\nBest hyperparameters:")
    print(study.best_params)
    print("Mean K-Fold Accuracy:", study.best_trial.user_attrs.get("kfold_mean_acc", "N/A"))

    with open(os.path.join(log_path, task_name + "_best_params.txt"), 'w') as f:
        f.write(str(study.best_params))
