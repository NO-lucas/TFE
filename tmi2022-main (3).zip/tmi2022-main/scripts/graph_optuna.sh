#!/bin/bash

#SBATCH --job-name=optuna_graph      # Nom du job
#SBATCH --output=optuna_graph.out    # Fichier de sortie
#SBATCH --error=optuna_graph.err     # Fichier d'erreur

#SBATCH --cpus-per-task=32
#SBATCH --ntasks=1
#SBATCH --partition=gpu
#SBATCH --gres=gpu:2
#SBATCH --qos=preemptible


# Charger les modules nécessaires
source ~/cyto_env/bin/activate
module load cp3
module load releases/2021a
module load Python/3.9.5-GCCcore-10.3.0
# module load python/python36_sl7_gcc73
module load releases/2023a
module load PyTorch/2.1.2-foss-2023a-CUDA-12.1.1
module load matplotlib/3.7.2-gfbf-2023a


# Aller dans le bon dossier (là où se trouve ton script train_optuna.py)
cd /home/ucl/inma/lhenneau/Cytology-fine-tuning/graph_transformer/tmi2022-main/

TRAIN_SET="$SPLITS_DIR/train.txt"
VAL_SET="$SPLITS_DIR/val.txt"
TEST_SET="$SPLITS_DIR/test.txt"

# Lancer l'optimisation avec Optuna
python train_optuna.py \
    --n_class 3 \
    --data_path "/home/ucl/inma/lhenneau/Cytology-fine-tuning/graph_transformer/tmi2022-main/graphs" \
    --train_set "$TRAIN_SET" \
    --val_set "$VAL_SET" \
    --test_set "$TEST_SET" \
    --model_path "/home/ucl/inma/lhenneau/Cytology-fine-tuning/graph_transformer/tmi2022-main/graph_transformer/saved_models_0" \
    --log_path "/home/ucl/inma/lhenneau/Cytology-fine-tuning/graph_transformer/tmi2022-main/graph_transformer/saved_models_0/runs" \
    --task_name "GraphCAM" \
    --batch_size 2  \
    --train \
    --log_interval_local 36 
