#!/bin/bash

#SBATCH --job-name=cyto_fine_tune  # Nom du job
#SBATCH --output=graph2.out  # Fichier de sortie
#SBATCH --error=graph2.err  # Fichier d'erreur

#SBATCH --cpus-per-task=32
#SBATCH --ntasks=1
#SBATCH --partition=gpu
#SBATCH --gres=gpu:2
#SBATCH --qos=preemptible

# Charger les modules nécessaires

# Activation de l'environnement virtuel
source ~/cyto_env/bin/activate
module load cp3
module load releases/2021a
module load Python/3.9.5-GCCcore-10.3.0
# module load python/python36_sl7_gcc73
module load releases/2023a
module load PyTorch/2.1.2-foss-2023a-CUDA-12.1.1
module load matplotlib/3.7.2-gfbf-2023a
# Chemin vers les fichiers .txt (assurez-vous que le dossier 'data_txt' contient les splits)
SPLITS_DIR="/home/ucl/inma/lhenneau/Cytology-fine-tuning/graph_transformer/tmi2022-main/data_txt"

# C:\Users\lucas\AAA_MEMOIRE\Code_Memoire\data_txt

# Nombre de folds (modifie cela si nécessaire)
NUM_FOLDS=15

# Boucle à travers chaque split
for i in $(seq 0 $((NUM_FOLDS - 1)))
do
    echo "Lancement de l'entraînement pour le fold $i..."
    FOLDER_NAME="/home/ucl/inma/lhenneau/Cytology-fine-tuning/graph_transformer/tmi2022-main/graph_transformer/saved_models_$i"
    mkdir -p $FOLDER_NAME


    # Spécifie les chemins pour les fichiers de train et val pour ce fold
    TRAIN_SET="$SPLITS_DIR/train_$i.txt"
    VAL_SET="$SPLITS_DIR/val_$i.txt"
    TEST_SET="$SPLITS_DIR/test_$i.txt"

   

    # Lance l'entraînement
    python /home/ucl/inma/lhenneau/Cytology-fine-tuning/graph_transformer/tmi2022-main/main.py \
    --n_class 3 \
    --data_path "/home/ucl/inma/lhenneau/Cytology-fine-tuning/graph_transformer/tmi2022-main/graphs" \
    --train_set "$TRAIN_SET" \
    --val_set "$VAL_SET" \
    --test_set "$TEST_SET" \
    --model_path "/home/ucl/inma/lhenneau/Cytology-fine-tuning/graph_transformer/tmi2022-main/graph_transformer/saved_models_$i" \
    --log_path "/home/ucl/inma/lhenneau/Cytology-fine-tuning/graph_transformer/tmi2022-main/graph_transformer/saved_models_$i/runs" \
    --task_name "GraphCAM" \
    --batch_size 2  \
    --train \
    --log_interval_local 36 \
    --n_features 7

    echo "Entraînement terminé pour le fold $i"
done
