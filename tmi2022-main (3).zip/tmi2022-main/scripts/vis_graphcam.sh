python src/vis_graphcam.py \
--path_file "cptac_lung_val2.txt" \
--path_patches "/run/media/yizheng/YiZ/CPTAC_data/patches" \
--path_WSI "/run/media/yizheng/YiZ/CPTAC/PKG - CPTAC-LUAD/LUAD" \
--path_graph "/scratch2/zheng/cptac_data/CPTAC_LUNG_features/simclr_files" \