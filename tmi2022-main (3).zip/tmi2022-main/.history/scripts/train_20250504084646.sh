#!/bin/bash

# Spécifie l'interpréteur Python dans l'environnement conda
PYTHON="./../../Cytology-fine-tuning/memoire/Scripts/python.exe"

# Active le GPU (si nécessaire)
export CUDA_VISIBLE_DEVICES=0

# Lance l'entraînement
"$PYTHON" main.py \
--n_class 3 \
--data_path "graphs" \
--train_set "train.txt" \
--val_set "val.txt" \
--model_path "C:\Users\lucas\tmi2022-main\tmi2022-main\graph_transformer\saved_models" \
--log_path "C:\Users\lucas\tmi2022-main\tmi2022-main\graph_transformer\saved_models/runs/" \
--task_name "GraphCAM" \
--batch_size 8 \
--train \
--log_interval_local 6
