PYTHON="./../../Cytology-fine-tuning/memoire/Scripts/python.exe"

export CUDA_VISIBLE_DEVICES=0
"$PYTHON" main.py \
--n_class 3 \
--data_path "C:\Users\lucas\AAA_MEMOIRE\Code_Memoire\graphs" \
--val_set "test.txt" \
--model_path "C:\Users\lucas\tmi2022-main\tmi2022-main\graph_transformer\saved_models" \
--log_path "C:\Users\lucas\tmi2022-main\tmi2022-main\graph_transformer\saved_models\runs" \
--task_name "GraphCAM" \
--batch_size 1 \
--test \
--log_interval_local 6 \
--resume "C:\Users\lucas\tmi2022-main\tmi2022-main\graph_transformer\saved_models\GraphCAM.pth" \
--graphcam
