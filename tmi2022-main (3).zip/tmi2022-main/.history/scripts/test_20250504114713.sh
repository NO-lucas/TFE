



#!/bin/bash

# Spécifie l'interpréteur Python dans l'environnement conda
PYTHON="./../../Cytology-fine-tuning/memoire/Scripts/python.exe"

# Active le GPU (si nécessaire)
export CUDA_VISIBLE_DEVICES=0

# Chemin vers les fichiers .txt (assurez-vous que le dossier 'data_txt' contient les splits)
SPLITS_DIR="C:\Users\lucas\AAA_MEMOIRE\Code_Memoire\data_txt"

# Nombre de folds (modifie cela si nécessaire)
NUM_FOLDS=15

# Boucle à travers chaque split
for i in $(seq 0 $((NUM_FOLDS - 1)))
do
    echo "Lancement de test pour le fold $i..."

    # Crée un dossier pour ce fold
    FOLDER_NAME="C:/Users/lucas/tmi2022-main/tmi2022-main/graph_transformer/saved_models_$i"
    mkdir -p $FOLDER_NAME

    # Spécifie les chemins pour les fichiers de train, val et test pour ce fol
    TEST_SET="$SPLITS_DIR\test_$i.txt"

    # Lance l'entraînement
    "$PYTHON" main.py \
    --n_class 3 \
    --data_path "C:\Users\lucas\AAA_MEMOIRE\Code_Memoire\graphs" \
    --val_set "$TEST_SET" \
    --model_path "C:\Users\lucas\tmi2022-main\tmi2022-main\graph_transformer\saved_models_$i" \
    --log_path "C:\Users\lucas\tmi2022-main\tmi2022-main\graph_transformer\saved_models_$i\runs" \
    --task_name "GraphCAM" \
    --batch_size 1 \
    --test \
    --log_interval_local 6
    --resume "C:\Users\lucas\tmi2022-main\tmi2022-main\graph_transformer\saved_models_$i\GraphCAM.pth"

    echo "Entraînement terminé pour le fold $i"
done
